#### Access the end points
POST: http://localhost:8080/myAccount
use payload :
{"customerId":1}

#H2 console

http://localhost:8080/h2-console
#### JDBC URL
jdbc:h2:mem:testdb
#####
https://github.com/prpramod/accounts/commit/e212f1d5de31c796912ce7dcfe585a465b63ea79